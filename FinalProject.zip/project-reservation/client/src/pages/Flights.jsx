import React, { useCallback, useState } from "react";

function Flights() {
  const [data, setData] = useState();
  const [date, setDate] = useState();

  const options = {
    method: "GET",
    headers: {
      "X-RapidAPI-Key": "d281ffa83cmsh7fa3f68cbd0d4c6p115823jsn2016468ada5b",
      "X-RapidAPI-Host": "flight-info-api.p.rapidapi.com",
    },
  };

  const fetchRequest = (e) => {
    fetch(
      `https://flight-info-api.p.rapidapi.com/schedules?version=v1&DepartureDate=${date}`,
      options
    )
      .then((response) => response.json())
      .then((response) => setData(response?.data))
      .catch((err) => console.error(err));
  };
  return (
    <div className="flights__container">
      <h2>Enter flight date</h2>
      <input
        type="date"
        value={date}
        onChange={(e) => setDate(e.target.value)}
      />
      <button className="flights__button" onClick={fetchRequest}>
        Search
      </button>

      <div className="flights__info">
        {data &&
          Object.keys(data).map((flight, i) => (
            <div className="flights__card" key={i}>
              <h3>Departure airport:</h3>
              <p>{data[flight].departure.airport.iata}</p>
              <h3>Flight number:</h3>
              <p>{data[flight].flightNumber}</p>
            </div>
          ))}
      </div>
    </div>
  );
}
export default Flights;
